from django.urls import path
from pools import views


from pools.views import Forms, StudentList, StudentDetail, StudentUpdate, StudentDelete

urlpatterns = [
 path('index/', views.index , name = "index"),
path('about/', views.about , name = "about"),
path('blog/', views.blog , name = "blog"),
path('contact/', views.contact , name = "contact"),
path('portfolio/', views.portfolio , name = "portfolio"),
path('', views.home , name = "home"),
path('register', views.register, name = 'register'),
    path('login_reg', views.login_reg, name = 'login'),
    path('logout', views.logoutuser, name = 'logout'),
path('students', views.students , name = "students"),
    path('add', Forms.as_view(), name = 'forms'),
    path('', StudentList.as_view(), name = 'list'),
    path('<pk>/detail', StudentDetail.as_view(), name = 'detail'),
    path('<pk>/update', StudentUpdate.as_view(), name = 'update'),
    path('<pk>/delete', StudentDelete.as_view(), name = 'delete'),
    

]