from django.contrib import admin

# Register your models here.
from pools.models import Student

admin.site.register(Student)