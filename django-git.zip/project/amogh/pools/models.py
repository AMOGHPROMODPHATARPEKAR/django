from django.db import models

# Create your models here.
class Student(models.Model):
    name = models.CharField(max_length=50)
    department = models.CharField(max_length=20)
    rollno = models.IntegerField(default = 10)
    def _str_(self):
        return self.name
